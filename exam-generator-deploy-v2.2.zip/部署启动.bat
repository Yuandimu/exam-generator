@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================
echo   智能出题系统 - 服务器部署启动
echo ============================================
echo.

:: 检查 Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未检测到 Python，请先安装 Python 3.8+
    echo 下载地址：https://www.python.org/downloads/
    echo 安装时请勾选 "Add Python to PATH"
    pause
    exit /b 1
)

:: 检查依赖是否已安装
python -c "import pptx; import PyPDF2; import docx" >nul 2>&1
if %errorlevel% neq 0 (
    echo [提示] 首次运行，正在安装依赖包...
    pip install python-pptx PyPDF2 python-docx -i https://pypi.tuna.tsinghua.edu.cn/simple
    if %errorlevel% neq 0 (
        echo [警告] 清华源安装失败，尝试默认源...
        pip install python-pptx PyPDF2 python-docx
    )
    echo.
)

echo [启动] 正在启动服务器...
echo.
python start_server_deploy.py

pause
