@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0"

echo ============================================
echo   Exam Generator - Deployment Diagnostics
echo ============================================
echo.

echo [1] Checking Python...
python --version 2>nul || (
    echo   [FAIL] Python NOT installed or not in PATH!
    goto :end
)
echo   [OK] Python is available

echo.
echo [2] Checking dependencies...
python -c "import pptx; print('  python-pptx:', pptx.__version__)" 2>nul && echo "  [OK]" || echo "  [MISSING] python-pptx"
python -c "import PyPDF2; print('  PyPDF2:', PyPDF2.__version__)" 2>nul && echo "  [OK]" || echo "  [MISSING] PyPDF2"
python -c "import docx; print('  python-docx:', docx.__version__)" 2>nul && echo "  [OK]" || echo "  [MISSING] python-docx"

echo.
echo [3] Checking files...
if exist index.html (echo "  [OK] index.html found") else (echo "  [MISSING] index.html")
if exist start_server_deploy.py (echo "  [OK] start_server_deploy.py found") else (echo "  [MISSING] start_server_deploy.py")

echo.
echo [4] Checking port 8080...
netstat -an | findstr ":8080" >nul && echo "  [WARN] Port 8080 is IN USE by another process!" || echo "  [OK] Port 8080 is free"

echo.
echo [5] Checking Windows Firewall...
netsh advfirewall firewall show rule name="ExamGenerator Port 8080" >nul 2>&1 && echo "  [OK] Firewall rule exists" || echo "  [INFO] No firewall rule (will auto-add on startup)"

echo.
echo [6] Testing local network...
ipconfig | findstr /i "IPv4" | findstr /v "127.0.0.1"
echo.

:end
echo ============================================
echo Diagnostics complete.
echo ============================================
pause
