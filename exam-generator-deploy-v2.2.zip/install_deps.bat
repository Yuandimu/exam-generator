@echo off
chcp 65001 >nul
echo ============================================
echo   智能出题系统 - 依赖安装
echo ============================================
echo.

:: 检查 Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未检测到 Python，请先安装 Python 3.8+
    echo 下载地址：https://www.python.org/downloads/
    echo 安装时请勾选 "Add Python to PATH"
    pause
    exit /b 1
)

echo [检测] Python 已安装
python --version
echo.

echo [安装] 正在安装所需依赖包...
echo.

pip install python-pptx PyPDF2 python-docx -i https://pypi.tuna.tsinghua.edu.cn/simple

if %errorlevel% neq 0 (
    echo.
    echo [警告] 清华源安装失败，尝试默认源...
    pip install python-pptx PyPDF2 python-docx
)

echo.
echo ============================================
echo   安装完成！
echo   双击 launch.bat 即可启动系统
echo ============================================
pause
