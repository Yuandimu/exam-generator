@echo off
chcp 65001 >nul 2>&1
cd /d "%~dp0"

echo ============================================
echo   Exam Generator Server
echo ============================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found!
    echo Please install Python 3.8+ first.
    echo Download: https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during install.
    pause
    exit /b 1
)

echo [OK] Python found:
python --version
echo.

python -c "import pptx; import PyPDF2; import docx" >nul 2>&1
if %errorlevel% neq 0 (
    echo [INFO] Installing dependencies...
    pip install python-pptx PyPDF2 python-docx -i https://pypi.tuna.tsinghua.edu.cn/simple
    if %errorlevel% neq 0 (
        echo [WARN] Tsinghua mirror failed, trying default...
        pip install python-pptx PyPDF2 python-docx
    )
    echo.
)

echo [STARTING] Starting server...
echo.
python start_server_deploy.py

pause
