@echo off
chcp 65001 >nul
cd /d "%~dp0"

echo ============================================
echo   智能出题系统 - 局域网分享模式
echo ============================================
echo.

for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
    set "IP=%%a"
    set "IP=!IP:~1!"
)

echo   本地访问：http://127.0.0.1:8080/index.html
echo   分享链接：http://!IP!:8080/index.html
echo.
echo   请将「分享链接」发给同事
echo   同事需和你在同一局域网（如公司内网）
echo.
echo   按 Ctrl+C 可停止服务器
echo ============================================

python -m http.server 8080
pause
